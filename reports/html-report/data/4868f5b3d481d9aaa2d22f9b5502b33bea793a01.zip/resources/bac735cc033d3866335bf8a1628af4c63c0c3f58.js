
		
		    window.canRun = true;
		    window.isAdEnabled = true;
		
	